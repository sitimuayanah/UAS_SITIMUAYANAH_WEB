<!-- CSS  -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="<?= base_url('asset/materialize/css/materialize.css'); ?>" type="text/css" rel="stylesheet" media="screen,projection" />
<link href="<?= base_url('asset/mystyle.css') ?>" type="text/css" rel="stylesheet" media="screen,projection" />

<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.3/js/materialize.min.js"></script>