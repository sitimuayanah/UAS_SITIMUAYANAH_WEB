<footer class="bgmhs">
    <p class="white-text center">Made by <a href="">Andri Ilham</a> &copy; 2020</p>
</footer>